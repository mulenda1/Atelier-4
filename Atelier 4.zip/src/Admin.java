class  admin extends personne {
    public admin(String nom, String postNom, String prenom) {
        super(nom, postNom, prenom);
    }
}
